# mltable 0.1.0 (2025-31-01)
## Bug Fixes
- Fixed a bug in the table rendering function.
- Improved error handling for invalid inputs.

## Improvements
- Updated documentation for clarity.


# mltable 0.0.0.9000 (2025-01-27)
- Initial release of the package.
- Added core functionality for creating and manipulating tables.
- Included basic documentation and examples.
